/**
 * A short and simple program to calculate the
 * total number of minutes and seconds
 * based on the hours input from the user
 * 
 * Created by: Garry
 * Created on: November 3, 2024
 */

#include <iostream>
using namespace std;
int main(){

   int hours, total_minutes, total_seconds;

    /*
        Total number of minutes in 1 hour
    */
    const int minutes_per_hour = 60;


    /*
        Total number of seconds in 60 minutes
    */
   const int seconds_per_minute = 60;

    //get the total hours from the user
    cout << "Enter number of hours: ";
    cin >> hours;

    total_minutes = hours * minutes_per_hour; //calculate the total number of minutes
    total_seconds = total_minutes * seconds_per_minute; //calculate the total number of seconds

    cout << "* ----------------------------------------------------------- *" << endl;
    cout << "Total hours: " << hours << endl;
    cout << "Total minutes: " << total_minutes << " in " << hours << " hours " << endl;
    cout << "Total seconds: " << total_seconds << " in " << hours << " hours " << endl; 
    cout << "* ------------------------------------------------------------ *" << endl;


    return 0;
}